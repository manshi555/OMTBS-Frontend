import { Component, OnInit } from '@angular/core';
import { MovieListService } from '../movie-list.service';
import { Theatre } from './Theatre';
import { Movie } from './Movie';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
              })
export class SearchComponent implements OnInit {
  theatreCity:String 
  theatreName :String
  movies : Movie []
  theatre : Theatre[];
  listOfMovies : Movie []
  theatreCities : String []
  theatreNames : String[]

  constructor(private myService:MovieListService, private router: Router, private route: ActivatedRoute ) { }
      
  ngOnInit(): void {
    
    this.myService.getAllCities().subscribe(data => {
      this.theatreCities = data;
    })
     
  }
 
  Navigate(value){
    this.myService.searchMovieByCity(value)
     .subscribe(data => {
      this.movies = data;
    });
    
  }
 
}
